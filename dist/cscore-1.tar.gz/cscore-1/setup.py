
from setuptools import setup
  
setup(
    name='cscore',
    version='1',
    description='Scoring the commonness from differential analysis',
    author='Hong Jiang',
    author_email='scilavisher@gmail.com',
    packages=['cscore'],
)
